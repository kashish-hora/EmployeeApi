package com.mongodb.repo;

import java.util.Optional;


import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.mongodb.models.Employee;
@Repository
public interface EmplyeeRepository extends MongoRepository<Employee,String>{

	
	

	
	
	

}
