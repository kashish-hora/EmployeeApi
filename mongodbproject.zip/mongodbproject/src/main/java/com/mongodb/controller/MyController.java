package com.mongodb.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mongodb.models.Employee;
import com.mongodb.repo.EmplyeeRepository;

@RestController
@RequestMapping("/employee")
public class MyController {
	@Autowired
	private EmplyeeRepository employeerepo;
	@PostMapping("/")
	public ResponseEntity<?> addEmployee(@RequestBody Employee employee){
		Employee save=this.employeerepo.save(employee);
		return ResponseEntity.ok(save);
		
	}
	@GetMapping("/")
	public ResponseEntity<?> getEmployee(){
		
		return ResponseEntity.ok(this.employeerepo.findAll());
		
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> getSingleEmployee(@PathVariable ("id") String id){
		Optional<Employee> empOptional=employeerepo.findById(id);
		if(empOptional.isPresent()) {
			return new ResponseEntity<>(empOptional.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>("Employee not found with id"+id,HttpStatus.NOT_FOUND);
			
		}
		
	}
	
	
	
	
	@DeleteMapping("/{id}")
    public void delete(@PathVariable ("id") Employee id) {
		
	            this.employeerepo.delete(id);
	            
	            
	    }
	
	@PutMapping("/{id}")
	public ResponseEntity<?> updateById(@PathVariable ("id") String id,@RequestBody Employee empnew){
		Optional<Employee> empOptional=employeerepo.findById(id);
		if(empOptional.isPresent()) {
			Employee empToSave=empOptional.get();
			 empToSave.setEmpname(empnew.getEmpname()!=null ? empnew.getEmpname():empToSave.getEmpname());
			 empToSave.setEmailid(empnew.getEmailid()!=null ? empnew.getEmailid():empToSave.getEmailid());
			 empToSave.setEmpid(empnew.getEmpid()!=null ? empnew.getEmpid():empToSave.getEmpid());
			 employeerepo.save(empToSave);
			 
			 
			 
			
			return new ResponseEntity<>(empToSave,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>("Employee not found with id"+id,HttpStatus.NOT_FOUND);
			
		}
		
	}
	
	
	
        
           

        

    }


